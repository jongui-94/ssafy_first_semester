package com.ssafy.springtest.util;

public class ValidationException {

}
