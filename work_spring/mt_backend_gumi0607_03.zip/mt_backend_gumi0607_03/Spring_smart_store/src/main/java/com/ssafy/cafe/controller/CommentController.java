package com.ssafy.cafe.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.cafe.model.dto.Comment;
import com.ssafy.cafe.model.service.CommentService;

import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@CrossOrigin(allowCredentials = "true", originPatterns = { "*" })
@RestController
@RequestMapping("/api")
public class CommentController {

	@Autowired
	private CommentService cService;

	@ApiOperation(value = "comment 객체를 추가한다.")
	@PostMapping("/comment")
	public ResponseEntity<?> insertComment(@RequestBody Comment comment) {
		cService.addComment(comment);

		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@ApiOperation(value = "comment 객체를 수정한다.")
	@PutMapping("/comment")
	public ResponseEntity<?> updateComment(@RequestBody Comment comment) {
		cService.updateComment(comment);
		
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@ApiOperation(value = "comment 객체를 삭제한다.")
	@DeleteMapping("/comment/{id}")
	public ResponseEntity<?> deleteComment(@PathVariable Integer id) {
		cService.removeComment(id);
		
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
