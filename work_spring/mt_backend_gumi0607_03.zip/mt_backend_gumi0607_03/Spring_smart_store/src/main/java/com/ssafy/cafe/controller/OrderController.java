package com.ssafy.cafe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.cafe.model.dto.Order;
import com.ssafy.cafe.model.service.OrderService;

import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@CrossOrigin(allowCredentials = "true", originPatterns = { "*" })
@RestController
@RequestMapping("/api")
public class OrderController {

	@Autowired
	private OrderService oService;

	@ApiOperation(value = "order 객체를 저장하고 추가된 Order의 Id를 반환한다.", response = Integer.class)
	@PostMapping("/order")
	public ResponseEntity<?> insertOrder(@RequestBody Order order) {
		oService.makeOrder(order);
		List<Order> orderList = oService.getOrdreByUser(order.getUserId());

		int id = orderList.get(orderList.size() - 1).getId();

		return new ResponseEntity<Integer>(id, HttpStatus.OK);
	}

	@ApiOperation(value = "{orderId}에 해당하는 주문의 상세 내역을 목록 형태로 반환한다. 이 정보는 사용자 정보 화면의 주문 내역 조회에서 사용된다.", response = Order.class)
	@GetMapping("/order/{orderId}")
	public ResponseEntity<?> getOrder(@PathVariable("orderId") Integer orderId) {
		Order order = oService.getOrderWithDetails(orderId);

		if (order != null) {
			return new ResponseEntity<Order>(order, HttpStatus.OK);
		} else {
			return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
		}
	}
}
