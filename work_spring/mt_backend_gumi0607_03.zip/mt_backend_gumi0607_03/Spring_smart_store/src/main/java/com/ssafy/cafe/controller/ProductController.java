package com.ssafy.cafe.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.cafe.model.dto.Product;
import com.ssafy.cafe.model.service.ProductService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(allowCredentials = "true", originPatterns = { "*" })
@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private ProductService pService;

	@ApiOperation(value = "전체 상품 목록을 반환한다.", response = List.class)
	@GetMapping("/product")
	public ResponseEntity<?> getProductList() {
		List<Product> productList = pService.getProductList();

		if (productList != null) {
			return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
		} else {
			return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
		}
	}

	@ApiOperation(value = "{productId}에 해당하는 상품의 정보를 comment와 함께 반환한다.", response = Product.class)
	@GetMapping("/product/{productId}")
	public ResponseEntity<?> getProduct(@PathVariable("productId") Integer productId) {
		List<Map<String, Object>> product = pService.selectWithComment(productId);
		
		if (product != null) {
			return new ResponseEntity<List<Map<String, Object>>>(product, HttpStatus.OK);
		} else {
			return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
		}
	}
}
