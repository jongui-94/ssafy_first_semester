package com.ssafy.cafe.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.cafe.model.dto.User;
import com.ssafy.cafe.model.service.UserService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(allowCredentials = "true", originPatterns = { "*" })
@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	private UserService uService;

	@ApiOperation(value = "로그인 처리 후 성공적으로 로그인 되었다면 loginId라는 쿠키를 내려보낸다.", response = User.class)
	@PostMapping("/user/login")
	public ResponseEntity<?> login(@RequestBody User user, HttpServletResponse response)
			throws UnsupportedEncodingException {
		User selected = uService.login(user);

		if (selected != null) {
			Cookie cookie = new Cookie("loginId", URLEncoder.encode(selected.getId(), "utf-8"));

			cookie.setPath("/");
			cookie.setMaxAge(10 * 60); // 초 단위, 10분
			response.addCookie(cookie);

			return new ResponseEntity<User>(selected, HttpStatus.OK);
		}

		return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
	}

	@ApiOperation(value = "loginId라는 쿠키를 찾아 제거한다.")
	@GetMapping("/user/logout")
	public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();

		for (Cookie cookie : cookies) {
			if (cookie.getName().equals("loginId")) {
				Cookie removeCookie = new Cookie("loginId", "");
				removeCookie.setPath("/");
				removeCookie.setMaxAge(0);
				response.addCookie(removeCookie);
				return new ResponseEntity<Void>(HttpStatus.OK);
			}
		}

		return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
	}

	@ApiOperation(value = "사용자의 정보와 함께 사용자의 주문 내역, 사용자 등급 정보를 반환한다.(미완성)", response = User.class)
	@PostMapping("/user/info")
	public ResponseEntity<?> info(@RequestParam String id, HttpServletResponse response)
			throws UnsupportedEncodingException {
		User selected = uService.info(id);

		if (selected != null) {
			return new ResponseEntity<User>(selected, HttpStatus.OK);
		}

		return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
	}

	@ApiOperation(value = "request parameter로 전달된 id가 이미 사용중인지 반환한다.", response = Boolean.class)
	@GetMapping("user/isUsed")
	public ResponseEntity<?> isUsed(@RequestParam String id, HttpServletResponse response) {
		boolean isUsed = uService.isUsedId(id);

		return new ResponseEntity<Boolean>(isUsed, HttpStatus.OK);
	}
}
