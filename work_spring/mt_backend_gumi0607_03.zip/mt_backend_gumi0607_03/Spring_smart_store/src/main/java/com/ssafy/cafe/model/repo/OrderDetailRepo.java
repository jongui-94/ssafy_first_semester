package com.ssafy.cafe.model.repo;

import java.util.List;

import com.ssafy.cafe.model.dto.OrderDetail;

public interface OrderDetailRepo {
    int insert(OrderDetail detail);

    int delete(Integer detailId);

    OrderDetail select(Integer detailId);

    List<OrderDetail> selectAll();
}
