package com.ssafy.cafe.model.repo;

import java.util.List;

import com.ssafy.cafe.model.dto.Product;

public interface ProductRepo {
	
    /**
     * 새로운 상품을 추가한다.
     * @param product
     * @return
     */
    int insert(Product product);

    /**
     * 상품을 수정한다.
     * @param product
     * @return
     */
    int update(Product product);

    /**
     * 상품을 삭제한다.
     * @param productId
     * @return
     */
    int delete(Integer productId);

    /**
     * 상품을 조회한다.
     * @param productId
     * @return
     */
    Product select(Integer productId);

    List<Product> selectAll();
}
