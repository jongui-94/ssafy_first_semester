package com.ssafy.cafe.model.repo;

import java.util.List;

import com.ssafy.cafe.model.dto.User;

public interface UserRepo {
	
    /**
     * 사용자 정보를 추가한다.
     * @param user
     * @return
     */
    int insert(User user);

    /**
     * 사용자의 Stamp 정보를 수정한다.
     * @param user
     * @return
     */
    int updateStamp(User user);

    /**
     * 사용자 정보를 조회한다.
     * @param userId
     * @return User
     */
    User select(String userId);

    /**
     * 로그인 기능을 수행한다.
     * @param userId
     * @return User
     */
    User login(User user);
    
    /**
     * 사용자 정보를 삭제한다.
     * @param userId
     * @return
     */
    int delete(String userId);
    
    /**
     * 모든 사용자를 반환한다.
     * @param 
     * @return List<User>
     */
    List<User> selectAll(); 
    
    /**
     * 사용자 정보를 수정한다.
     * @param User
     * @return
     */
    int update(User user);
}
