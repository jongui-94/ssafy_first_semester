package com.ssafy.cafe.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.cafe.model.dto.Comment;
import com.ssafy.cafe.model.repo.CommentRepo;

@Service
public class CommentServiceImpl implements CommentService {

	@Autowired
	private CommentRepo cRepo;

	@Override
	public void addComment(Comment comment) {
		cRepo.insert(comment);
	};

	@Override
	public Comment selectComment(Integer id) {
		return cRepo.select(id);
	};

	@Override
	public void removeComment(Integer id) {
		cRepo.delete(id);
	};

	@Override
	public void updateComment(Comment comment) {
		cRepo.update(comment);
	};

	@Override
	public List<Comment> selectByProduct(Integer productId) {
		List<Comment> list = cRepo.selectByProduct(productId);

		return list;
	};

}
