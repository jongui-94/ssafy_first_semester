package com.ssafy.cafe.model.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.cafe.model.dto.Order;
import com.ssafy.cafe.model.dto.OrderDetail;
import com.ssafy.cafe.model.dto.Stamp;
import com.ssafy.cafe.model.dto.User;
import com.ssafy.cafe.model.repo.OrderDetailRepo;
import com.ssafy.cafe.model.repo.OrderRepo;
import com.ssafy.cafe.model.repo.StampRepo;
import com.ssafy.cafe.model.repo.UserRepo;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepo oRepo;

	@Autowired
	private OrderDetailRepo dRepo;

	@Autowired
	private UserRepo uRepo;

	@Autowired
	private StampRepo sRepo;

	@Override
	public void makeOrder(Order order) {
		// 주문 등록
		int result = oRepo.insert(order);

		if (result > 0) {
			// 방금 등록된 주문의 id 받기
			List<Order> orders = oRepo.selectAll();
			int orderId = orders.get(orders.size() - 1).getId();

			// order의 OrderDetail 리스트
			List<OrderDetail> details = order.getDetails();

			int total = 0; // 현재 주문에서 받을 수 있는 스탬프 수

			// orderDetail 별로 얻을 수 있는 스탬프 더하기
			for (int i = 0; i < details.size(); i++) {
				OrderDetail detail = details.get(i);
				total += detail.getQuantity();

				// detail에 주문 번호를 삽입 후 db에 추가
				detail.setOrderId(orderId);
				dRepo.insert(details.get(i));
			}

			// user의 stampList에 stamp객체를 추가
			Stamp stamp = new Stamp(order.getUserId(), orderId, total);
			sRepo.insert(stamp);

			// UserDao 객체 받기
			User user = uRepo.select(order.getUserId());
			user.getStampList().add(0, stamp);

			user.setStamps(total + user.getStamps()); // 스탬프 개수 갱신
			uRepo.updateStamp(user);
		}
	}

	@Override
	public Order getOrderWithDetails(Integer orderId) {
		Order order = oRepo.selectWithDetail(orderId);

		List<OrderDetail> temp = new ArrayList<OrderDetail>();

		List<OrderDetail> orderDetailList = dRepo.selectAll();
		for (OrderDetail orderDetail : orderDetailList) {
			if (orderDetail.getOrderId() == orderId) {
				temp.add(orderDetail);
			}
		}

		order.setDetails(temp);

		return order;
	}

	@Override
	public List<Order> getOrdreByUser(String id) {
		List<Order> orders = oRepo.selectByUser(id);

		return orders;
	}

	@Override
	public void updateOrder(Order order) {
		oRepo.update(order);
	}

	@Override
	public List<Map> selectOrderTotalInfo(int id) {
		// back-end 관통에서 추가
		return null;
	}

}
