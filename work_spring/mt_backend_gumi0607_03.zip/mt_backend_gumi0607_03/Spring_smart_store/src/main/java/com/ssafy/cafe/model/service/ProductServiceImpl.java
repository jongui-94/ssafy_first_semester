package com.ssafy.cafe.model.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.cafe.model.dto.Comment;
import com.ssafy.cafe.model.dto.Order;
import com.ssafy.cafe.model.dto.OrderDetail;
import com.ssafy.cafe.model.dto.Product;
import com.ssafy.cafe.model.repo.CommentRepo;
import com.ssafy.cafe.model.repo.OrderDetailRepo;
import com.ssafy.cafe.model.repo.OrderRepo;
import com.ssafy.cafe.model.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepo pRepo;

	@Autowired
	private CommentRepo cRepo;
	
	@Autowired
	private OrderDetailRepo dRepo;
	
	@Override
	public List<Product> getProductList() {		
		return pRepo.selectAll();
	}

	@Override
	public List<Map<String, Object>> selectWithComment(Integer productId) {
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
	
		Map<String, Object> pInfo = new HashMap<String, Object>();
		
		// 상품 정보를 가져온다.
		Product product = pRepo.select(productId);
		
		// 상품에 대한 코멘트를 모두 더한다.
		List<Comment> commentList = cRepo.selectByProduct(productId);
		System.out.println(commentList);
		product.getCommentList().addAll(commentList);
		System.out.println(product.getCommentList());

		pInfo.put("product", pRepo.select(productId));
		result.add(pInfo);
		
		Map<String, Object> orderCount = new HashMap<String, Object>();

		int total = 0;
		// 모든 상세 주문을 가지고 온다.
		List<OrderDetail> orderDetailList = dRepo.selectAll();
		for (OrderDetail orderDetail : orderDetailList) {
			if(orderDetail.getProductId() == product.getId()) {
				total += orderDetail.getQuantity();
			}
		}
		orderCount.put("orderCount", total);
		result.add(orderCount);
		
		return result;
	}

}
