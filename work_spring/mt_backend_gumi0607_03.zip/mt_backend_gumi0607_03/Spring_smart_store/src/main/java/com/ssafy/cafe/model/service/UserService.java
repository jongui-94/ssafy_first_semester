package com.ssafy.cafe.model.service;

import com.ssafy.cafe.model.dto.User;


public interface UserService {

    public void join(User user);

    public User login(User user);
    
    public User info(String id);

    public void leave(String id);
    
    public boolean isUsedId(String id);

}
