package com.ssafy.cafe.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.cafe.model.dto.User;
import com.ssafy.cafe.model.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo repo;

	@Override
	public void join(User user) {
		repo.insert(user);
	}

	@Override
	public User login(User user) {
		return repo.login(user);
	}

	@Override
	public User info(String id) {
		return repo.select(id);
	}

	@Override
	public boolean isUsedId(String id) {
		User user = repo.select(id);

		if (user == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public void leave(String id) {
	}

}
