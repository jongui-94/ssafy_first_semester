package com.ssafy.cafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSmartStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
